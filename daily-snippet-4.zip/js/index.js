var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _toArray(arr) { return Array.isArray(arr) ? arr : Array.from(arr); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Noise = function () {
  function Noise() {
    _classCallCheck(this, Noise);

    this.p = new Array(512);
    this.permutation = this._shuffle(this._range(1, 255));

    for (var i = 256; i--;) {
      this.p[256 + i] = this.p[i] = this.permutation[i];
    }
  }

  _createClass(Noise, [{
    key: 'do',
    value: function _do(x) {
      var y = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
      var z = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;

      this.X = Math.floor(x) & 255;
      this.Y = Math.floor(y) & 255;
      this.Z = Math.floor(z) & 255;

      x -= Math.floor(x);
      y -= Math.floor(y);
      z -= Math.floor(z);

      this.u = this._fade(x);
      this.v = this._fade(y);
      this.w = this._fade(z);

      this.A = this.p[this.X] + this.Y;
      this.AA = this.p[this.A] + this.Z;
      this.AB = this.p[this.A + 1] + this.Z;

      this.B = this.p[this.X + 1] + this.Y;
      this.BA = this.p[this.B] + this.Z;
      this.BB = this.p[this.B + 1] + this.Z;

      return this._scale(this._lerp(this.w, this._lerp(this.v, this._lerp(this.u, this._grad(this.p[this.AA], x, y, z), this._grad(this.p[this.BA], x - 1, y, z)), this._lerp(this.u, this._grad(this.p[this.AB], x, y - 1, z), this._grad(this.p[this.BB], x - 1, y - 1, z))), this._lerp(this.v, this._lerp(this.u, this._grad(this.p[this.AA + 1], x, y, z - 1), this._grad(this.p[this.BA + 1], x - 1, y, z - 1)), this._lerp(this.u, this._grad(this.p[this.AB + 1], x, y - 1, z - 1), this._grad(this.p[this.BB + 1], x - 1, y - 1, z - 1)))));
    }
  }, {
    key: '_scale',
    value: function _scale(n) {
      return (1 + n) / 2;
    }
  }, {
    key: '_fade',
    value: function _fade(t) {
      return t * t * t * (t * (t * 6 - 15) + 10);
    }
  }, {
    key: '_lerp',
    value: function _lerp(t, a, b) {
      return a + t * (b - a);
    }
  }, {
    key: '_grad',
    value: function _grad(hash, x, y, z) {
      var h = hash & 15;
      var u = h < 8 ? x : y;
      var v = h < 4 ? y : h == 12 || h == 14 ? x : z;

      return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
    }
  }, {
    key: '_range',
    value: function _range(a, z) {
      var results = [];

      for (var i = a; i <= z; i++) {
        results.push(i);
      }

      return results;
    }
  }, {
    key: '_shuffle',
    value: function _shuffle(_ref) {
      var _ref2 = _toArray(_ref),
          arr = _ref2.slice(0);

      var m = arr.length;

      while (m) {
        var i = Math.floor(Math.random() * m--);

        var _ref3 = [arr[i], arr[m]];
        arr[m] = _ref3[0];
        arr[i] = _ref3[1];
      }

      return arr;
    }
  }]);

  return Noise;
}();

var settings = {
  x: 20,
  y: 20,
  z: 200
};

var gui = new dat.GUI();

gui.add(settings, 'x', 10, 100).step(5);
gui.add(settings, 'y', 10, 100).step(5);
gui.add(settings, 'z', 10, 1000).step(10);

var stats = new Stats();

stats.setMode(0);
stats.domElement.style.position = 'absolute';
stats.domElement.style.left = '15px';
stats.domElement.style.top = '0px';
document.body.appendChild(stats.domElement);

var Playground = function () {
  function Playground(config) {
    _classCallCheck(this, Playground);

    this.config = config;

    this.canvas = this.config.canvas;
    this.ctx = this.canvas.getContext('2d');

    this.noise = this.config.noise;

    this.size = this.config.size;
    this.offset = this.config.offset;

    this.tick = 0;

    window.addEventListener('resize', this._setSize.bind(this), false);
  }

  _createClass(Playground, [{
    key: '_setSize',
    value: function _setSize() {
      this.canvas.width = window.innerWidth;
      this.canvas.height = window.innerHeight;
    }
  }, {
    key: 'update',
    value: function update() {}
  }, {
    key: 'loop',
    value: function loop() {
      window.requestAnimationFrame(this.loop.bind(this));
      stats.begin();

      this.tick++;

      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      for (var i = this.size; i--;) {
        this.ctx.fillStyle = 'rgba(255, 255, 255, ' + i / 20 + ')';
        for (var j = this.size; j--;) {
          var _x = this.canvas.width / 2 - this.offset * this.size / 2 + j * this.offset + 20;
          var _y = this.canvas.height / 2 - this.offset * this.size / 2 + i * this.offset - 50;

          this.ctx.beginPath();
          // this.ctx.fillStyle = '#fff'
          this.ctx.arc(_x - this.noise.do(i / settings.x, j / settings.y, this.tick / settings.z) * 33, _y + this.noise.do(i / settings.x, j / settings.y, this.tick / settings.z) * 100, 1, 0, Math.PI * 2, false);
          this.ctx.fill();
          this.ctx.closePath();
        }
      }

      stats.end();
    }
  }, {
    key: 'start',
    value: function start() {
      this._setSize();
      this.loop();
    }
  }]);

  return Playground;
}();

var pg = new Playground({
  canvas: document.getElementById('playground'),
  noise: new Noise(),
  size: 40,
  offset: 6
});

pg.start();

var popupBtn = document.querySelector('.popup__btn');
var popup = document.querySelector('.popup');

popupBtn.addEventListener('click', function (e) {
  popupBtn.classList.toggle('popup__btn_close');
  popup.classList.toggle('popup_show');
}, false);